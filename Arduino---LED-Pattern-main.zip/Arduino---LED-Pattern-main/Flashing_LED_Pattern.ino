int red_one = 2;
int red_two = 5;
int green_one = 3;
int green_two = 7;
int blue_one = 4;
int blue_two = 6;

void setup() {
pinMode(red_one, OUTPUT);
pinMode(red_two, OUTPUT);
pinMode(green_one, OUTPUT);
pinMode(green_two, OUTPUT);
pinMode(blue_one, OUTPUT);
pinMode(blue_two, OUTPUT);
}

void loop() {
digitalWrite(red_one, HIGH);
delay(75);
digitalWrite(red_one, LOW);
delay(75);
digitalWrite(red_one, HIGH);
delay(75);
digitalWrite(red_one, LOW);
delay(500);
digitalWrite(green_one, HIGH);
delay(75);
digitalWrite(green_one, LOW);
delay(75);
digitalWrite(green_one, HIGH);
delay(75);
digitalWrite(green_one, LOW);
delay(500);
digitalWrite(blue_one, HIGH);
delay(75);
digitalWrite(blue_one, LOW);
delay(75);
digitalWrite(blue_one, HIGH);
delay(75);
digitalWrite(blue_one, LOW);
delay(500);
digitalWrite(red_two, HIGH);
delay(75);
digitalWrite(red_two, LOW);
delay(75);
digitalWrite(red_two, HIGH);
delay(75);
digitalWrite(red_two, LOW);
delay(500);
digitalWrite(blue_two, HIGH);
delay(75);
digitalWrite(blue_two, LOW);
delay(75);
digitalWrite(blue_two, HIGH);
delay(75);
digitalWrite(blue_two, LOW);
delay(500);
digitalWrite(green_two, HIGH);
delay(75);
digitalWrite(green_two, LOW);
delay(75);
digitalWrite(green_two, HIGH);
delay(75);
digitalWrite(green_two, LOW);
delay(500);
}
