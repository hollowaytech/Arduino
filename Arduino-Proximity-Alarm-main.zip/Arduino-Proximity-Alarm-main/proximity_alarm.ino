 const int PIN_LIGHT = 2;
 const int PIN_TRIG = 3;
 const int PIN_ECHO = 4;
 const int PIN_BUZZ = 5;
 const int PIN_LIGHT_TWO = 6;

 long duration;
 float distance;
 
const int safetyDistance = 20;

 void setup() {
  pinMode(PIN_LIGHT, OUTPUT);
  pinMode(PIN_TRIG, OUTPUT);
  pinMode(PIN_ECHO, INPUT);
  pinMode(PIN_BUZZ, OUTPUT);
  pinMode(PIN_LIGHT_TWO, OUTPUT);
  Serial.begin(9600);
}
void loop() {
 digitalWrite(PIN_TRIG, LOW);
 delayMicroseconds(2);

 digitalWrite(PIN_TRIG, HIGH);
 delayMicroseconds(10);
 digitalWrite(PIN_TRIG, LOW);

 duration = pulseIn(PIN_ECHO, HIGH);
 distance = duration * 0.034 / 2;

 Serial.print("Distance: ");
 Serial.print(distance);
 Serial.print(" cm");

 if (distance > 0 && distance <= safetyDistance) {
    digitalWrite(PIN_LIGHT, HIGH);   
    digitalWrite(PIN_LIGHT_TWO, LOW); 
    tone(PIN_BUZZ, 1000); 
  } else {
    digitalWrite(PIN_LIGHT, LOW); 
    digitalWrite(PIN_LIGHT_TWO, HIGH);    
    noTone(PIN_BUZZ);  
  }
  
  delay(100);
}
